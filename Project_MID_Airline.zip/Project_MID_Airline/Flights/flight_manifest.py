# In this file we will create the flight manifest that will allow the airport assistant
# to verify the id of each passenger right before they board the plane and will act as a final count

# Create a FlightTrip object
#output the list of passngers
# method to change variable id_match from true to false
# method to output the final list of passengers boarding

class FlightManifest:
    def __init__(self):
        pass


    def id_match(self):
        # set variable to true based on a user input, for example, the input asks them if the id matches with each passenger one by one
        # while loop and if statements based on the user input
        # use list from flight trip object
        pass

    def call_police(self):
        print("The police have been alerted!!!!")

