# Below we are specifying cities distance in km from london:

distances = {"Brussels": 300, "Paris": 340, "Amsterdam": 360, "Dublin": 470, "Berlin": 940, "Copenhagen": 994,
                "Madrid": 1260, "Rome": 1380, "Stockholm": 1530, "Lisbon": 1550}
