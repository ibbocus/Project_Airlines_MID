
from Project_MID_Airline.Databases.database_connection import Database_OOP
import pyodbc
import pandas as pd
# from Project_MID_Airline.Flights.flight_path import brussels1
# Here we will initiate the Passengers class:
from Project_MID_Airline.Flights.flight_manifest import FlightManifest


class Passengers:

    def create_table(self):
        a = Database_OOP()  # fix naming convetions
        a.connect_sql()
        cursor = a.connect_sql()
        table_name = "passengers"
        sql_command = f"""
    CREATE TABLE {table_name}
    (
    passengerID int IDENTITY (1,1) NOT NULL,
    first_name VARCHAR(300),
    last_name VARCHAR(300),
    passport_number VARCHAR(300),
    dob VARCHAR(300),
    upcoming_flight VARCHAR(300),
    flight_destination VARCHAR(300),
    airmiles VARCHAR(300),
    previous_flights VARCHAR(300),
    )
    """
        cursor.execute(sql_command)
        cursor.commit()

    def existing_customers(self):
        a = Database_OOP()
        cursor = a.connect_sql()
        b = Passengers()

        query = '''

            INSERT
            INTO
            passengers(first_name, last_name, passport_number, dob, upcoming_flight, flight_destination, airmiles,
                       previous_flights)
            VALUES

            ('Ibrahim', 'Bocus', '170994GLPR', '02/09/1996', 'True', 'Paris', '2500', 'london'),
            ('Daniel', 'Teegan', '150193FRHT', '17/08/1999', 'True', 'Brussels', '0', 'london'),
            ('Mehdi', 'Shamaa', '020390AQWS', '22/02/2000', 'True', 'Rome', '3487', 'Dublin'),
            ('Tony', 'Hawk', '210799LQRV', '20/12/1991', 'True', 'Madrid', '2087', 'Lisbon'),
            ('Jack', 'Bauer', '221290QPWR', '29/09/1987', 'False', 'Paris', '9023', 'N/A')

            '''
        cursor.execute(query)
        cursor.commit()

    def table_init(self):
        self.create_table()
        self.existing_customers()

    def insert_passenger_info(self):
        a = Database_OOP()
        cursor = a.connect_sql()
        b = Passengers()
        enter_info = True
        while enter_info:

            while True:
                try:
                # First name user input
                    first_name = input("Please enter the customers First Name: ")
                    if len(first_name) <= 2 or len(first_name) > 20:
                        raise ValueError
                    break
                except ValueError:
                    print("ERROR: Please enter a valid first name")

            while True:
                try:
                # Second name user input
                    last_name = input("Please enter the customers Last Name: ")
                    if len(last_name) <= 2 or len(last_name) > 20:
                        raise ValueError
                    break
                except ValueError:
                    print("ERROR: Please enter a valid last name")

            while True:
                try:
            # Passport number user input
                    passport_number = input("Please enter the customers 10-character Passport Number: ")
                    if len(passport_number) < 10 or len(passport_number) > 10:
                        raise ValueError
                    break
                except ValueError:
                    print("ERROR: Please enter a valid passport number (10 characters) ")

            while True:
                try:
                    # Date of birth user input
                    dob = input("Please enter the customers Date of Birth in the following format (DD/MM/YYYY): ")
                    if len(str(dob)) < 10 or len(str(dob)) > 10:
                        raise ValueError
                    break
                except ValueError:
                    print("ERROR: Please enter a valid date of birth. In the following format (DD/MM/YYYY)")

            while True:
                try:
            # Upcoming flight user input
                    upcoming_flight = input("Does the customer have an upcoming flight? (TRUE or FALSE): ")
                    if (upcoming_flight != "TRUE" and "FALSE") and (len(upcoming_flight) < 2 or len(upcoming_flight)) > 6:
                        raise ValueError
                    break
                except ValueError:
                    print("ERROR: Please enter a valid choice TRUE or FALSE: ")

            while True:
                try:
            # Upcoming flight destination user input
                    flight_destination = input("Please enter the customers Flight Destination: ")
                    if len(flight_destination) < 2 or len(flight_destination) > 30:
                        raise ValueError
                    break
                except ValueError:
                    print("ERROR: Please enter a valid destination")

            while True:
                try:
            # Airmiles user input
                    airmiles = (input(
                        "How many Air Miles has the customer accumulated: "))
                    if len(airmiles) > 10:
                        raise ValueError
                    break
                except ValueError:
                    print("ERROR: please check and try again")

            while True:
                try:
            # Last flight user input
                    previous_flights = input("Please enter the customers previous flight with MID Airlines. If its their first flight enter N/A: ")
                    if len(previous_flights) < 3 or len(previous_flights) > 30:
                        raise ValueError
                    break
                except ValueError:
                    print("ERROR: Please enter a valid destination")

            query1 = f"""
            INSERT INTO passengers
            (
                first_name, last_name, passport_number, dob,  upcoming_flight, flight_destination, airmiles, previous_flights
            )
            VALUES
            (
                '{first_name}', '{last_name}', '{passport_number}', '{dob}', '{upcoming_flight}', '{flight_destination}','{airmiles}', '{previous_flights}'
            )
            """
            cursor.execute(query1)
            cursor.commit()
            break_loop = input("Would you like to continue?: Y/N")
            if break_loop == "N":
                enter_info = False
            else:
                b.insert_passenger_info()

    def select_passengers(self):
        a = Database_OOP()
        a.connect_sql()
        a.connect_sql()
        cursor2 = a.connect_sql()
        query = "SELECT * FROM passengers"
        rows = cursor2.execute(query)  # execute query using connection/ cursor
        first_name = []  # Initialise an empty list for each column
        last_name = []
        passport_number = []
        date_of_birth = []
        upcoming_flight = []
        upcoming_flight_destination = []
        airmiles = []
        last_flight = []
        for firstname, lastname, passportno, dob, upcoming, upcomingdestination, air_miles, lastflight in rows:  # a slightly different name goes here
            first_name.append(firstname)  # list goes first, slightly different name goes in brackets
            last_name.append(lastname)
            passport_number.append(passportno)
            date_of_birth.append(dob)
            upcoming_flight.append(upcoming)
            upcoming_flight_destination.append(upcomingdestination)
            airmiles.append(air_miles)
            last_flight.append(lastflight)
        df_passengers = pd.DataFrame()
        df_passengers[
            'First Name'] = first_name  # name a column 'First Name' then make it equal to the list you initialised
        df_passengers['Last Name'] = last_name
        df_passengers['Passport Number'] = passport_number
        df_passengers['Date of Birth'] = date_of_birth
        df_passengers['Upcoming Flight'] = upcoming_flight
        df_passengers['Upcoming Flight Destination'] = upcoming_flight_destination
        df_passengers['Air Miles'] = airmiles
        df_passengers['Previous Flight Destination'] = last_flight
        print(df_passengers)
        # Naming the column 'Date' and filling it with the data from the list previously created
        return df_passengers

    def create_manifest(self):
        db = Database_OOP()
        db.connect_sql()
        cursor = db.connect_sql()
        manifest_input = input("Which destination would you like to create a manifest for? ")
        if manifest_input == ("brussels" or "Brussels"):
            destination = "Brussels"
        elif manifest_input == ("Paris" or "paris"):
            destination = "Paris"
        elif manifest_input == ("Amsterdam" or "amsterdam"):
            destination = "Amsterdam"
        elif manifest_input == ("Dublin" or "dublin"):
            destination = "Dublin"
        elif manifest_input == ("Berlin" or "berlin"):
            destination = "Berlin"
        elif manifest_input == ("Copenhagen" or "copenhagen"):
            destination = "Copenhagen"
        elif manifest_input == ("Madrid" or "madrid"):
            destination = "Madrid"
        elif manifest_input == ("Rome" or "rome"):
            destination = "Rome"
        elif manifest_input == ("Stockholm" or "stockholm"):
            destination = "Stockholm"
        elif manifest_input == ("Lisbon" or "lisbon"):
            destination = "lisbon"

        query = f"SELECT * FROM passengers WHERE flight_destination LIKE '{destination}'"
        rows = cursor.execute(query)
        passengerid = []
        first_name = []  # Initialise an empty list for each column
        last_name = []
        passport_number = []
        date_of_birth = []
        upcoming_flight = []
        upcoming_flight_destination = []
        airmiles = []
        last_flight = []
        for passengerID, firstname, lastname, passportno, dob, upcoming, upcomingdestination, air_miles, lastflight in rows:
            print(firstname)
            passengerid.append(passengerID)
            first_name.append(firstname)
            last_name.append(lastname)
            passport_number.append(passportno)
            date_of_birth.append(dob)
            upcoming_flight.append(upcoming)
            upcoming_flight_destination.append(upcomingdestination)
            airmiles.append(air_miles)
            last_flight.append(lastflight)
        df_passengers = pd.DataFrame()
        df_passengers['First Name'] = first_name
        df_passengers['Last Name'] = last_name
        df_passengers['Passport Number'] = passport_number
        df_passengers['Date of Birth'] = date_of_birth
        df_passengers['Upcoming Flight'] = upcoming_flight
        df_passengers['Upcoming Flight Destination'] = upcoming_flight_destination
        df_passengers['Air Miles'] = airmiles
        df_passengers['Previous Flight'] = last_flight
        print(df_passengers)

    def id_checker(self):
        db = Database_OOP()
        db.connect_sql()
        cursor = db.connect_sql()
        # destination = input("What flight are you checking?")

        query = f"SELECT first_name FROM passengers "
        first_name = str(input("What is the first name of the passenger? "))
        rows = cursor.execute(query)
        fname = []
        for firstname, val in rows:
            fname.append(firstname)
            print(fname)

        if first_name in fname:
            print("Success! ID matches with customer")
        else:
            manifest = FlightManifest()
            manifest.call_police()

# WHERE flight_destination = '{destination}'
# q = Passengers()
# q.id_checker()

# a = Passengers()
# # a.create_table()
# # a.insert_passenger_info()
# a.create_manifest()
