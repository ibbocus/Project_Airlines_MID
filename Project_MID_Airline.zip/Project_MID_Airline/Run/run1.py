from Project_MID_Airline.Run.gui import Ui
from PyQt5 import QtWidgets
import sys


app = QtWidgets.QApplication(sys.argv)  # Create an instance of QtWidgets.QApplication
window = Ui()  # Create an instance of our class
app.exec_()  # Start the application
