from PyQt5 import QtWidgets, uic
from Project_MID_Airline.Planes.Plane_747 import B747
from Project_MID_Airline.Planes.Plane_787 import B787
from Project_MID_Airline.Planes.Plane_A381 import A380
from Project_MID_Airline.Flights.flight_path import Flights
from Project_MID_Airline.Flights.flight_path import FlightInfo
from Project_MID_Airline.Databases.database_connection import Database_OOP
import sys

# for table init execute the database run file
# this will host the GUI
#
#
#
# # 1. show login screen - Enter username and password
# # 2. show welcome page with options to access passengers, flights and planes
# # 2.a Passengers will show shoow all passnegers/insert passenger info/create manifest
#
# def run():
#     # SHOW LOGIN SCREEN
#     password = "password"
#     if input("please enter password") == password:
#         pass
#         # SHOW WELCOME SCREEN
#     if input("Please select function ")

class Ui(QtWidgets.QTabWidget):
    def __init__(self):
        super(Ui, self).__init__()  # Call the inherited classes __init__ method
        uic.loadUi('Project_MID.ui', self)  # Load the .ui file

        # PLANE INFO FUNCTIONS
        self.b747 = self.findChild(QtWidgets.QPushButton, 'Qplanes_print_747')
        self.b747.clicked.connect(self.b747_info)

        self.b787 = self.findChild(QtWidgets.QPushButton, 'Qplanes_prints_787')
        self.b787.clicked.connect(self.b787_info)

        self.a380 = self.findChild(QtWidgets.QPushButton, 'Qplanes_print_A380')
        self.a380.clicked.connect(self.a380_info)

        # Flight Functions
            # Create flight
        self.display = self.findChild(QtWidgets.QLabel, 'Qcreate_flight_prompts')
        self.display.setText("Please click Create Flight to begin")


        self.create_flight = self.findChild(QtWidgets.QPushButton, 'Qflights_createflights')
        self.create_flight.clicked.connect(self.create_flight_input_prompt)


            # Name flight
        self.flight_name = self.findChild(QtWidgets.QPushButton, 'Qflight_input')
        self.flight_name.clicked.connect(self.flight_name_input_prompt)

            # set destination
        self.destination = self.findChild(QtWidgets.QPushButton, 'Qdestination_input')
        self.destination.clicked.connect(self.destination_input_prompt)

            # set timeslot
        self.timeslot = self.findChild(QtWidgets.QPushButton, 'Qtime_input')
        self.timeslot.clicked.connect(self.timeslot_input_prompt)

            # set plane_model
        self.timeslot = self.findChild(QtWidgets.QPushButton, 'Qplane_input')
        self.timeslot.clicked.connect(self.plamemodel_input)



        self.show()

    # Plane Methods
    def b747_info(self):
        plane = B747()
        self.display = self.findChild(QtWidgets.QLabel, 'Qplane_info_label')
        self.display.setText(plane.flight_capacity())

    def b787_info(self):
        plane = B787()
        self.display = self.findChild(QtWidgets.QLabel, 'Qplane_info_label')
        self.display.setText(plane.flight_capacity())

    def a380_info(self):
        plane = A380()
        self.display = self.findChild(QtWidgets.QLabel, 'Qplane_info_label')
        self.display.setText(plane.flight_capacity())

    # Flight Methods

    def create_flight_input_prompt(self):
        self.display = self.findChild(QtWidgets.QLabel, 'Qcreate_flight_prompts')
        self.display.setText("Please enter a flight name")

    def flight_name_input_prompt(self):
        self.input = self.findChild(QtWidgets.QLineEdit, 'Qcreate_flights_inputs')
        flight_name = self.input.text()
        self.display = self.findChild(QtWidgets.QLabel, 'Qcreate_flight_prompts')
        self.display.setText("Please enter a destination")
        global flight_info
        flight_info = []
        flight_info.append(flight_name)
        print(flight_name)
        self.input.clear()

    def destination_input_prompt(self):
        self.input = self.findChild(QtWidgets.QLineEdit, 'Qcreate_flights_inputs')
        self.display.setText("What time is the flight?")
        destination = self.input.text()
        print(destination)
        flight_info.append(destination)
        self.input.clear()

    def timeslot_input_prompt(self):
        self.display = self.findChild(QtWidgets.QLabel, 'Qcreate_flight_prompts')
        self.display.setText("What model is the plane?")
        timeslot = self.input.text()
        print(timeslot)
        flight_info.append(timeslot)
        self.input.clear()

    def plamemodel_input(self):
        self.display = self.findChild(QtWidgets.QLabel, 'Qcreate_flight_prompts')
        self.display.setText("information has been stored in database")
        plane_model = self.input.text()
        print(plane_model)
        flight_info.append(plane_model)

        db = Database_OOP()
        db.connect_sql()
        cursor = db.connect_sql()
        query = f'''
        INSERT INTO flights(flight_name, plane_model, destination, timeslot)
        VALUES
        ('{flight_info[0]}', '{flight_info[3]}', '{flight_info[1]}', '{flight_info[2]}')
        '''
        cursor.execute(query)
        cursor.commit()
        return

# app = QtWidgets.QApplication(sys.argv)  # Create an instance of QtWidgets.QApplication
# window = Ui()  # Create an instance of our class
# app.exec_()  # Start the application
